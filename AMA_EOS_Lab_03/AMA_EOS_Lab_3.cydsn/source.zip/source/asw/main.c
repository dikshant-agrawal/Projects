/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "global.h"
#include "tft.h"
#include "ringbuffer.h"
#include "parser.h"
#include "message.h"

#define UART_ERROR_STATES (UART_LOG_RX_STS_BREAK | UART_LOG_RX_STS_PAR_ERROR | UART_LOG_RX_STS_STOP_ERROR | UART_LOG_RX_STS_OVERRUN)
#define SIZE_BUFFER 512
#define SIZE_TEMP_BUFFER 128
ringbuffer_hdl_t bufferObject;
char buffer[SIZE_BUFFER];
volatile uint32_t counterValue = 0;
Parser_t jsonParser;
MSG_messagebox_t msgBox;
MSG_id_t signal;

/*
void UART_Error_Handler(uint8_t UART_Error_Code){
    //UART_LOG_PutChar('H');
    //UART_LOG_PutChar(UART_Error_Code);
}
*/

int main(void)
{
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //Set systick period to 1 ms. Enable the INT and start it.
	EE_systick_set_period(MILLISECONDS_TO_TICKS(1, BCLK__BUS_CLK__HZ));
	EE_systick_enable_int();

    
    for(;;)
    {
        StartOS(OSDEFAULTAPPMODE); 
    }
}
void unhandledException(){
    __asm("bkpt");
}

TASK(Task_Init){
    
    //Initialization
    UART_LOG_Start();
    TFT_init();
    TFT_setBacklight(100);
    TFT_fillScreen(WHITE);
    TFT_setTextColor(BLACK);
    TFT_print("HAA BETA");
    
    Ringbuffer_Init(&bufferObject, RINGBUFFER_NO_ERIKA_RES, buffer, SIZE_BUFFER);
    
    if(PARSER_init(&jsonParser) != RC_SUCCESS){
        UART_LOG_PutString("INIT FAIL");
    }
    
    /*
    
    char buf[36];
    char buf1[36];
    uint32_t length;
    
        for(int i = 0; i< 10; i++){
            uint8_t readData = i;
            PARSER_addChar(&jsonParser, readData);
            if(readData == 9){
                jsonParser.content[10] = '\0';
                
                char output[11];
                for(int i = 0; i< 10; i++){
                    output[i] = jsonParser.content[i] + '0';
                }
                output[10] = '\0';
                UART_LOG_PutString(output);
                }
            
        }
*/

    EE_system_init();
    EE_systick_start();

    SetRelAlarm(Alarm_1ms, 1000, 100);
    
    ActivateTask(Task_JSON);
    ActivateTask(Task_TFT);
    
    TerminateTask();

}

TASK(Task_Blink){
    counterValue++;
    TerminateTask();
}

TASK(Task_UART){
    TerminateTask;
}

TASK(Task_JSON){
    EventMaskType ev;
    uint32_t length;
    char tempPayload[SIZE_BUFFER];
    signal.m_signal = 1;
    signal.m_event = 1;
    
    MSG_init(&msgBox, SIZE_TEMP_BUFFER, ev_json, Task_TFT, res_msgBox);

    while(1){
        WaitEvent(ev_json);
        GetEvent(Task_JSON, &ev);
        ClearEvent(ev);
        
        if(ev & ev_json){
            length = bufferObject.filled;
            
            if(Ringbuffer_Read(&bufferObject, tempPayload, length) == RC_SUCCESS){
                GetResource(res_printf);
                //UART_LOG_PutString(tempPayload);
                
                /*
                * Calling JSON Parser API to read the data from ring buffer and store it in 
                */
                for(uint32_t i = 0; i < length; i++){
                    PARSER_addChar(&jsonParser, tempPayload[i]);
                }
                //Debug statement
                PARSER_dbg_printContent(&jsonParser);
                
                PARSER_parse(&jsonParser);
                MSG_sendMessage(&msgBox, tempPayload, length, signal);
                
                //Clear the jsonParser object
                PARSER_clear(&jsonParser);
                
                ReleaseResource(res_printf);
            }
        } 
    }
    TerminateTask();
}
TASK(Task_TFT){
    EventMaskType ev;
    char buf[128];

    while(1){
        WaitEvent(ev_tft);
        GetEvent(Task_TFT, &ev);
        ClearEvent(ev);

        if(ev& ev_tft){
            uint32_t length = MSG_getFillLevel(&msgBox);
            MSG_receiveMessage(&msgBox, buf, length, &signal);
            UART_LOG_PutString(buf);
        }   
    }
    
    TerminateTask();
}

TASK(Task_Background){
    while(1){
      __asm("nop");
    }
}


//ISR which will increment the systick counter every ms 
ISR(systick_handler) {
     CounterTick(Counter_Systick); 
}

ISR2(isr_uartRx){
   
    uint8_t readData;
    uint8_t readStatus;
    uint8_t UART_LOG_errorStatus = 0u;
    do{
        readStatus = UART_LOG_RXSTATUS_REG;
        readData = readStatus;
        
        if((readStatus & UART_ERROR_STATES) != 0u){
            UART_LOG_errorStatus |= (readStatus & UART_ERROR_STATES);
            //UART_Error_Handler(UART_LOG_errorStatus);
        }
        
        if((readStatus & UART_LOG_RX_STS_FIFO_NOTEMPTY) != 0){
            readData = UART_LOG_RXDATA_REG;
            if((Ringbuffer_Write(&bufferObject, &readData, 1u)) == RC_SUCCESS){
                if(readData == 0x00){
                    SetEvent(Task_JSON, ev_json);
                } 
            }
        }
    }
    
    while((readStatus & UART_LOG_RX_STS_FIFO_NOTEMPTY)!= 0u);
  
}


/* [] END OF FILE */
